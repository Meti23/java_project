

import java.util.Scanner;

public class instructor extends person  implements interface2{
    private String fname;
    private String lname;
    private String email;
    private String tcourse;
    private String sresult;
    public String sattendance;

    public String getfname() {
        return fname;
    }
    public void setfname(String fname) {
        this.fname = fname;
    }
    public String getlname() {
        return lname;
    }
    public void setlname(String lname) {
        this.lname = lname;
    }
    public String getemail() {
        return email;
    }
    public void setemail(String email) {
        this.email = email;
    }
    public String gettcourse() {
        return tcourse;
    }
    public void settcourse(String tcourse) {
        this.tcourse = tcourse;
    }
    public String getsresult() {
        return sresult;
    }
    public void setsresult(String sresult) {
        this.sresult = sresult;
    }
    public String getsattendance() {
        return sattendance;
    }
    public void setsattendance(String sattendance) {
        this.sattendance = sattendance;
    }
    Scanner in= new Scanner(System.in);

    public void login(){
        System.out.println("if you are registered instructor please log in");
        System.out.println("----------------------------------------------");
        System.out.println("Email/user name:");
        Scanner in=new Scanner(System.in);
        email=in.nextLine();
        System.out.println("Password:");
        String password = in.nextLine();
        System.out.println("----------------------------------------------");
        System.out.println("----------------------------------------------");
    }
    public void addInfo(){
        //instructors can add his name and address
        System.out.println("Enter your information here");
        System.out.print("First name: ");
        this.fname=in.nextLine();
        System.out.print("Last name: ");
        this.lname=in.nextLine();
        System.out.print("Email: ");
        this.email=in.nextLine();
        System.out.println();
        System.out.println("Entered successfuly. It will be displayed for students");

    }
    public void addTcourse(){
        //add the instructor's course that the instructor teaches
        int cn;
        System.out.println("Enter the number of courses you want to add.");
        cn=in.nextInt();
        String [] newId=new String[cn];
        System.out.println("please Enter Course id.");
        for (int i=0;i<cn;i++){
            newId[i]=in.nextLine();
        }
        if(newId.equals(Cid))
            System.out.println("Course(s) found Thankyou.");
    }
    public void addResult(){
        //the instructor add students result here
        int sn;
        System.out.println("Please Enter the number of students.");
        sn=in.nextInt();
        String [] sresult=new String[sn];
        System.out.println("Please Enter the student's id and result");
        for(int i=0;i<sn;i++){
            id[i]=in.nextLine();
            for(int j=0;j<=i;j++){
                sresult[j]=in.nextLine();
            }
        }
    }
    public void addAttendance(){
        //the instructor add students attendance here
        int n;
        System.out.println("Please Enter the number of students.");
        n=in.nextInt();
        String [] sattendance=new String[n];
        System.out.println("Please Enter the student's id and student's result respectively");
        for(int i=0;i<n;i++){
           id[i]=in.nextLine();
            sattendance[i]=in.nextLine();
        }
    }
    public void display(){
        //Displays the instructor's full name and address
        System.out.println(getfname());
        System.out.println(getlname());
        System.out.println(getemail());
        System.out.println(gettcourse());
        System.out.println(getsresult());
        System.out.println(getsattendance());


    }
    public void choose() {
        //Allow the instructor to choose from the choices
        System.out.println("1:To add your Name and Address.");
        System.out.println("2:To add your course you are teaching.");
        System.out.println("3:To add student's result.");
        System.out.println("4:To add student's attendance.");
        System.out.println("5:To Display all entered Information");
        System.out.println("6:press 0 to exit.");


    }



}
