import java.util.Scanner;
public class mainn {
    public static void main(String[] args) {
        person Person1= new person();
        Person1.displayMessage();
        instructor ins=new instructor();
        Student stud= new Student();
        course m = new course();
        minicourse mm = new minicourse();
        System.out.println("Please choose the number");
        System.out.println("1.Instructor");
        System.out.println("2.Student");
        Scanner ni=new Scanner(System.in);
        int choice=ni.nextInt();
        //main choice
        switch(choice){
            case 1:
                ins.login();
                System.out.println("Please choose the number");
                System.out.println("1.To add your information");
                System.out.println("2.To add course you want to teach");
                System.out.println("3.To add student result");
                System.out.println("4.To add student attendance");
                System.out.println("5.To display your information");

                ins.choose();
                Scanner in=new Scanner(System.in);
                int choose=in.nextInt();

                while(choose!=0) {

                    if (choose == 0) {
                        System.out.println("exit");
                    }
                    //instructor choice
                    switch (choose) {
                        case 1:
                            ins.addInfo();
                            break;
                        case 2:
                            ins.addTcourse();
                            break;
                        case 3:
                            ins.addResult();
                            break;
                        case 4:
                            ins.addAttendance();
                            break;
                        case 5:
                            ins.display();
                            break;
                        default:
                            System.out.println("you entered the wrong number, please enter 1-5 numbers.");
                            break;}
                    m.display();

                    choice = in.nextInt();}


                break;
            case 2:
                stud.login();
                System.out.println("Please choose the number");
                System.out.println("1.To add a course");
                System.out.println("2.To edit your courses");
                System.out.println("3.To withdraw from a course");
                System.out.println("4.To print available courses information");
                System.out.println("5.To search course");
                System.out.println("6.To show your mark");
                System.out.println("7.To calculate your mark");


                m.setcName("java");
                m.setCid("j");
                m.setCourse_type("add");
                m.setCourse_year(2012);
                in = new Scanner(System.in);

                m.display();

                choice = in.nextInt();

                while (choice != -1) {

                    if (choice == -1) {
                        System.out.println("exit");
                    }

                    switch (choice) {
                        case 1:
                            m.addCourse();
                            break;
                        case 2:
                            m.editCourse();
                            break;

                        case 3:
                            m.deleteCourse();
                            break;

                        case 4:
                            m.printCourse();
                            break;

                        case 5:
                            m.searchCourse();
                            break;
                        case 6:
                            m.calresult();
                        case 7:
                            mm.calresult();
                        default:
                            System.out.println("you entered the wrong number ,please enter 1-5 numbers.");
                            break;
                    }
                    m.display();
                    choice = in.nextInt();
                }

            default:
                System.out.println("you entered the wrong number, please enter 1-2 numbers.");
                break;
        }
    }
}






