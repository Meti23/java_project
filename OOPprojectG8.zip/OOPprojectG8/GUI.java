package com.example.demo4;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import static javafx.application.Application.launch;


public class Gui extends Application {
    Scene scene1,scene2,scene3,scene4,scene5;





    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("front page");
        Text txt = new Text("Student page");
        txt.setFont(Font.font("Arial", 25));
        Button button1 = new Button("login");
        button1.setOnAction(e -> stage.setScene(scene2));
        Button button2 = new Button("sign up");
        button2.setOnAction(e -> stage.setScene(scene3));
        VBox layout1 = new VBox();
        layout1.setStyle("-fx-background-color: GREY;");
        layout1.setAlignment(Pos.CENTER);
        layout1.setSpacing(30);
        layout1.getChildren().addAll(txt, button1, button2);
        scene1 = new Scene(layout1, 400, 600);
        Text tt = new Text("Log in page");
        Label L1 = new Label("email");
        Label L2 = new Label("password");
        TextField tf2 = new TextField();
        TextField tf1 = new TextField();
        HBox form1 = new HBox();
        form1.setSpacing(5);
        form1.setAlignment(Pos.CENTER);
        form1.getChildren().addAll(L1, tf1);
        HBox form2 = new HBox();
        form2.setSpacing(5);
        form2.setAlignment(Pos.CENTER);
        form2.getChildren().addAll(L2, tf2);
        VBox form3 = new VBox();
        form1.setSpacing(10);
        Button button3 = new Button("Submit");
        button3.setOnAction(e -> stage.setScene(scene4));
        form3.setAlignment(Pos.CENTER);
        form3.getChildren().addAll(tt, form1, form2, button3);
        scene2 = new Scene(form3, 400, 600);
        Text f1 = new Text("Sign up page");
        Label Lf1 = new Label("Name");
        Label Lf2 = new Label("Age");
        Label Lf4 = new Label("Gender");
        Label Lf3 = new Label("ID");
        TextField txf1 = new TextField();
        TextField txf2 = new TextField();
        TextField txf3 = new TextField();
        ComboBox<String> Gender = new ComboBox<String>();
        Gender.getItems().add("Female");
        Gender.getItems().add("Male");
        HBox F1 = new HBox();
        F1.setSpacing(5);
        F1.setAlignment(Pos.CENTER);
        F1.getChildren().addAll(Lf1, txf1);
        HBox F2 = new HBox();
        F2.setSpacing(5);
        F2.setAlignment(Pos.CENTER);
        F2.getChildren().addAll(Lf2, txf2);
        HBox F3 = new HBox();
        F3.setSpacing(5);
        F3.setAlignment(Pos.CENTER);
        F3.getChildren().addAll(Lf3, txf3);
        HBox F4 = new HBox();
        F4.setSpacing(5);
        F4.setAlignment(Pos.CENTER);
        F4.getChildren().addAll(Lf4, Gender);
        Button button8 = new Button("Submit");
        button8.setOnAction(e -> stage.setScene(scene4));
        VBox fin = new VBox();
        fin.setStyle("-fx-background-color: blue;");
        fin.setSpacing(10);
        fin.setAlignment(Pos.CENTER);
        fin.getChildren().addAll(f1, F2, F3, F4, button8);
        scene3 = new Scene(fin, 400, 600);
        Text mainn = new Text("Welcome to our page");
        mainn.setFont(Font.font("Arial", 15));
        mainn.setX(20);
        mainn.setY(500);
        HBox x1 = new HBox();
        Button b1 = new Button("My profile");
        Button b2 = new Button("courses");
        Button b3 = new Button("class mates");
        Label nw1 = new Label("Add course");
        Label nw2 = new Label("Search course");

        Label nw4 = new Label("Add project");
        Label nw8 = new Label("For instructor");
        TextField tx1 = new TextField();
        TextField tx2 = new TextField();
        TextField tx3 = new TextField();
        Button b4 = new Button("Add");
        Button b5 = new Button("search");
        Button b6 = new Button("submit");
        Button b8 = new Button("show Result");

        Label nw11 = new Label("Add course");
        Label nw12 = new Label("Search course");

        Button nw14= new Button("check project");

        VBox x2 = new VBox();
        x2.setStyle("-fx-background-color: GREY;");
        x1.setSpacing(30);
        x2.setSpacing(30);
        x1.getChildren().addAll(b1, b2, b3);

        HBox F6= new HBox();
        F6.setSpacing(5);
        F6.setAlignment(Pos.CENTER);
        F6.getChildren().addAll(nw1, tx1,b4);
        HBox F7 = new HBox();
        F7.setSpacing(5);
        F7.setAlignment(Pos.CENTER);
        F7.getChildren().addAll(nw2, tx2,b5);
        HBox F8 = new HBox();
        F8.setSpacing(5);
        F8.setAlignment(Pos.CENTER);
        F8.getChildren().addAll(b8);
        HBox F9 = new HBox();
        F9.setSpacing(5);
        F9.setAlignment(Pos.CENTER);
        F9.getChildren().addAll(nw4, tx3,b6);

        Button b11= new Button("Add");
        Button b12= new Button("search");
        Button b13= new Button("submit");

        TextField tx11 = new TextField();
        TextField tx12= new TextField();
        TextField tx13= new TextField();
        HBox F11= new HBox();
        F11.setSpacing(5);
        F11.setAlignment(Pos.CENTER);
        F11.getChildren().addAll(nw11, tx11,b11);
        HBox F12 = new HBox();
        F12.setSpacing(5);
        F12.setAlignment(Pos.CENTER);
        F12.getChildren().addAll(nw12, tx12,b12);

        HBox F14 = new HBox();
        F14.setSpacing(5);
        F14.setAlignment(Pos.CENTER);
        F14.getChildren().addAll(nw14);
        BorderPane bp = new BorderPane();
        VBox v1= new VBox();
        v1.setStyle("-fx-background-color: GREY;");
        v1.setSpacing(30);
        Button b20 = new Button("Instructor");
        v1.getChildren().addAll(F6,F7,F8,F9,b20);
        VBox v2= new VBox();
        v2.setStyle("-fx-background-color: blue;");
        v2.setSpacing(30);
        v2.getChildren().addAll(F11,F12,F14);
        scene5 = new Scene(v2, 400, 600);
        OKHandlerClass handler1 = new OKHandlerClass();
        proHandlerClass handler2 = new proHandlerClass();
        prochHandlerClass handler3= new prochHandlerClass();
        resultHandlerClass handler4 = new resultHandlerClass();
        searchHandlerClass handler5= new searchHandlerClass();
        ProfileHandlerClass handler6= new ProfileHandlerClass();
        AddHandlerClass handler7= new AddHandlerClass();

        b11.setOnAction(handler1);
        b4.setOnAction(handler1);
        b6.setOnAction(handler2);
        nw14.setOnAction(handler3);
        b8.setOnAction(handler4);
        b12.setOnAction(handler5);
        b5.setOnAction(handler5);
        b1.setOnAction(handler6);
        b2.setOnAction(handler7);

        b20.setOnAction(e -> stage.setScene(scene2));
        bp.setTop(x1);
        bp.setCenter(mainn);
        bp.setCenter(v1);
        bp.setBackground(new Background(new BackgroundFill(Color.BLUE, null, null)));

        scene4 = new Scene(bp, 400, 600);
        stage.setScene(scene1);
        stage.show();
    }
    class OKHandlerClass implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation alert Dialog");
            alert.setContentText("Please confirm");
            alert.setHeaderText("Confirmation");
            alert.showAndWait();
        }}
        class searchHandlerClass implements EventHandler<ActionEvent> {
            @Override
            public void handle(ActionEvent e) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Search alert Dialog");
                alert.setContentText("Searching...");
                alert.setHeaderText("Found/Not Found");
                alert.showAndWait();
            }}
            class resultHandlerClass implements EventHandler<ActionEvent> {
                @Override
                public void handle(ActionEvent e) {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Result");
                    alert.setContentText("GPA=3.45");
                    alert.setHeaderText("Your Result is");
                    alert.showAndWait();
                }}
                class proHandlerClass implements EventHandler<ActionEvent> {
                    @Override
                    public void handle(ActionEvent e) {
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("Projects");
                        alert.setContentText("SUBMITTED");
                        alert.setHeaderText("PROJECT FOR COURSE ID- 003");
                        alert.showAndWait();
                    }}
                    class prochHandlerClass implements EventHandler<ActionEvent> {
                        @Override
                        public void handle(ActionEvent e) {
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.setTitle("Projects");
                            alert.setContentText("Projects submitted for your course are - project1002(c003), project3454(c005)");
                            alert.setHeaderText("PROJECT FOR COURSE ID- 003");
                            alert.showAndWait();
                        }}

    }



    class ProfileHandlerClass implements EventHandler<ActionEvent> {

            Label H1, H3, H4;
            HBox x2;
            BorderPane bp;

            @Override
            public void handle(ActionEvent t) {
                Text info;
                info= new Text("Welcome to The students page... Here is your log in information");


            }
        }




        class AddHandlerClass implements EventHandler<ActionEvent> {
            Label H1, H2, H3, H4;
            HBox x2;
            BorderPane bp;

            public void handle(ActionEvent t) {

                try {
                    H1 = new Label("Welcome to The students page");
                    H2 = new Label("Hello");
                    FlowPane x2 = new FlowPane();
                } catch (Exception ex) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("please correct your code");
                    alert.showAndWait();
                    return;
                }
                if (t.getSource() == null) {

                    x2.getChildren().add(H1);
                    bp.setCenter(x2);
                } else if (t.getSource() == H1) {

                    x2.getChildren().add(H2);
                    bp.setCenter(x2);
                }
            }



        public static void main (String[]args){
            launch(args);
        }
    }
