import java.util.Scanner;




public class course  {
    private String cName;
    private String Cid;
    private String course_type;
    private int course_year;
    String getcName() {
        return cName;
    }
    public void setcName(String cName) {
        this.cName = cName;
    }
    public String getCid() {
        return Cid;
    }
    public void setCid(String cid) {
        this.Cid = cid;
    }


    public String getCourse_type() {
        return course_type;
    }


    public void setCourse_type(String course_type) {
        this.course_type = course_type;
    }


    public int getCourse_year() {
        return course_year;
    }
    public void setCourse_year(int course_year) {
        this.course_year = course_year;
    }
    Scanner input=new Scanner(System.in);

    public void addCourse(){
        int n;
        System.out.println("how many course do you wanna take");
        n=input.nextInt();
        String [] cName= new String[n];
        String [] Cid= new String[n];
        String [] course_type= new String[n];
        int [] course_year= new int[n];
        System.out.println("Please Enter the number of courses");
        n=input.nextInt();
        System.out.println("Please Enter course name,course ID,course type and year respectively");
        for(int i=0;i<n;i++) {
            cName[i]=input.nextLine();
            Cid[i]=input.nextLine();
            course_type[i]=input.nextLine();
            course_year[i]=input.nextInt();
        }
        System.out.println("----------------------------------------------");
        System.out.println("----------------------------------------------");
        take(cName,n);
    }
    public void take(String []cName,int n){
        System.out.println("the courses you are taking are: ");

        for(int i=0; i<n;i++){
            System.out.println((i+1)+", "+cName[i]);
        }
        System.out.println("----------------------------------------------");
    }

    public void editCourse(){
        //changes course name or year
        System.out.println("Please Enter the number of courses you want to delete");
        System.out.println("Please Enter the course ID");
        int n=input.nextInt();
        String [] Cidd= new String[n];
        String [] Cid= new String[n];
        String [] cName= new String[n];

        for(int i=0;i<n;i++) {
            Cidd[i] = input.nextLine();
        }

        for(int i=0;i<n;i++) {
            if(Cidd[i].equals(Cid[i]))
                System.out.println("Write the new name");
            cName[i] = input.nextLine();
            System.out.println(cName[i]);
            {
            }
        }

    }
    public void deleteCourse() {
        System.out.println("Please Enter the number of courses you want to delete");
        System.out.println("Please Enter the course ID");
        int n=input.nextInt();
        String [] Cidd= new String[n];
        String [] Cid= new String[n];
        String [] cName= new String[n];

        for(int i=0;i<n;i++) {
            Cidd[i] = input.nextLine();
        }

        for(int i=0;i<n;i++) {
            if (Cidd[i].equals(Cid[i])){
                System.out.println("Write the new name");
                cName[i] = input.nextLine();
                System.out.println(cName[i]);}
            else{
                System.out.println("incorrect id .try again!!");
            }
        }

    }

    public void printCourse() {
        //prints all details of a course

        System.out.println("this are the information of course id,course type,course name and course year");
        System.out.println("the course id is "+getCid());
         System.out.println("the course type is "+getCourse_type());
        System.out.println("the course name is "+getcName());
        System.out.println("the course year is "+getCourse_year());


    }
    public void searchCourse() {
        String ID;
        System.out.println("Enter the courseID");
        ID=input.nextLine();
        if(ID.equals(Cid)) {
            System.out.println(cName);}

    }
    public void display() {
        System.out.println("this are the choices enter the number of your choice 1-5.to exit enter -1.");
        System.out.println("1:To add courses.");
        System.out.println("2:To edit courses.");
        System.out.println("3:To delete courses.");
        System.out.println("4:To print courses.");
        System.out.println("5:To search courses.");
        System.out.println("6:press -1 to exit.");

    }
    public void calresult() { //calculates result based on registered credit hour


        final int NUM_OF_COURSES = 4;
        int[] credits= {3,4,2,4};
        char[] grades;
        grades = new char[NUM_OF_COURSES];



        int creditsSum = 0;

        int totalPoints = 0;
        for(int i=0;i<4;i++) {



            creditsSum = creditsSum + credits[i];
        }

        for(int i = 0; i < 4 ; i++)

        {



            System.out.print("Enter grade for course "+(i+1)+": ");

            char grade = input.next().charAt(0);

            grades[i] = grade;



            switch(grade)

            {

                case 'A':

                case 'a': grade = 4; break;

                case 'B':

                case 'b': grade = 3; break;

                case 'C':

                case 'c': grade = 2; break;

                case 'D':

                case 'd': grade = 1; break;

                case 'F':

                case 'f': grade = 0; break;

            }



            totalPoints = totalPoints + (grade * credits[i]);

        }



        System.out.println("\nTotal number of credits: "+creditsSum);



        System.out.println("Total number of points: "+totalPoints);



        double gpa = 0;

        gpa = (double)totalPoints / creditsSum;

        if(gpa > 0)

            System.out.printf("\nGPA:%5.2f", gpa);

        else

            System.out.println("\nGPA:  0.00");

    }

}

class minicourse extends course{// subclass of course
    public void calresult() { //applying polymorphism (different definition for calresult)
        Scanner input = new Scanner (System.in);

        final int NUM_OF_COURSES = 4;
        int[] credits;

        credits = new int[NUM_OF_COURSES];

        char[] grades;

        grades = new char[NUM_OF_COURSES];



        int creditsSum = 0;

        int totalPoints = 0;



        for(int i = 0; i < NUM_OF_COURSES ; i++)

        {

            System.out.print("Enter credits for course "+(i+1)+": ");

            int credit = input.nextInt();

            credits[i] = credit;



            System.out.print("Enter grade for course "+(i+1)+": ");

            char grade = input.next().charAt(0);

            grades[i] = grade;



            switch(grade)

            {

                case 'A':

                case 'a': grade = 4; break;

                case 'B':

                case 'b': grade = 3; break;

                case 'C':

                case 'c': grade = 2; break;

                case 'D':

                case 'd': grade = 1; break;

                case 'F':

                case 'f': grade = 0; break;

            }



            creditsSum = creditsSum + credit;

            totalPoints = totalPoints + (grade * credit);

        }



        System.out.println("\nTotal number of credits: "+creditsSum);



        System.out.println("Total number of points: "+totalPoints);



        double gpa = 0;

        gpa = (double)totalPoints / creditsSum;

        if(gpa > 0)

            System.out.printf("\nGPA:%5.2f", gpa);

        else

            System.out.println("\nGPA:  0.00");

    }

}






