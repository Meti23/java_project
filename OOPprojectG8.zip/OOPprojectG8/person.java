
public class person{
    private String name;
    private String lname;
    private int id;
    private int age;
    private char  gender;


    public void setFname(String n)
    {
        this.name=n;
    }

    public void setLname(String l)
    {
        this.name=l;
    }

    public void seAge(int a)
    {
        this.age=a;
    }
    public void setGender(char g)
    {
        this.gender=g;
    }

    public void setId(int  i)
    {
        this.id=i;
    }


    public String getFname()
    {
        return name;
    }

    public String getLname()
    {
        return name;

    }
    public int  getId()
    {
        return id;
    }
    public int getAge()
    {
        return age;
    }
    public char getGender()
    {
        return gender;
    }

    public void displayMessage()
    {
        System.out.println("*******************************************************************************************");
        System.out.println("WELLCOME TO COURSE MANAGMENT SYSTEM");
        System.out.println("********************************************************************************************");
    }



}

