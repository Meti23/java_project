//interface for instructor and student classes
public interface interface2 {
    String Cid="c001";
    String[] id=
            {"S001","S002","S003"};
    void display();
    void login();


}
