
import java.util.*;

public class Student extends person implements interface2 {
    private String Fname;
    private String Lname;
    private String id;
    private String email;
    private String password;



    public Student(String Fname,String Lname,String id){
        this.Fname=Fname;
        this.Lname=Lname;
        this.id=id;

    }
    public Student(){
        this.Fname=Fname;
        this.Lname=Lname;
        this.id=id;
    }

    public String getFname(){
        return Fname;
    }
    public String getLname(){
        return Lname;
    }
    public String getID(){
        return id;
    }
    public String getEmail(){
        return email;
    }
    public String getPassword(){
        return password;
    }

    public void setFname(String Fname){
        this.Fname=Fname;
    }
    public void setLname(String Lname){
        this.Lname=Lname;
    }
    public void setID(String id){
        this.id=id;
    }
    public void setEmail(String email){
        this.email=email;
    }
    public void setPassword(String password){
        this.password=password;
    }

    public void login(){
        System.out.println("if you are registered student please log in");
        System.out.println("----------------------------------------------");
        System.out.println("Email/user name:");
        Scanner in=new Scanner(System.in);
        email=in.nextLine();
        System.out.println("Password:");
        password =in.nextLine();
        System.out.println("----------------------------------------------");
        System.out.println("----------------------------------------------");
    }
    public void register(){
        System.out.println("if you haven't registered please complete the following form");
        System.out.println("Enter your First name: ");
        Scanner in=new Scanner(System.in);
        Fname=in.nextLine();
        System.out.println("Enter your Last name");
        Lname=in.nextLine();
        System.out.println("Enter your ID");
        id=in.nextLine();
        System.out.println("Enter a password");
        password=in.nextLine();
        System.out.println("----------------------------------------------");
        System.out.println("----------------------------------------------");
    }
    public void choose(){
        int n;
        System.out.println("how many course do you wanna take");
        Scanner in=new Scanner(System.in);
        n=in.nextInt();
        String [] courses= new String[n];
        System.out.println("enter the name of the courses you want to take");
        for(int i=0; i<n;i++){
            courses[i]=in.nextLine();
        }
        System.out.println("----------------------------------------------");
        System.out.println("----------------------------------------------");
        take(courses,n);
    }
    public void take(String []courses,int n){
        System.out.println("the courses you are taking are: ");

        for(int i=0; i<n;i++){
            System.out.println((i+1)+", "+courses[i]);
        }
        System.out.println("----------------------------------------------");
    }
    public void project_submitted(ArrayList<String> projects){
        System.out.println("----------------------------------------------");
        System.out.println("the projects you have submitted are: ");
        for(String proj:projects)
            System.out.println(proj+", ");
        System.out.println("----------------------------------------------");
        System.out.println("----------------------------------------------");

    }
    public void project(){
        ArrayList<String> projects=new ArrayList<>();
        Scanner input=new Scanner(System.in);
        System.out.println("enter the projects you want to submit, enter end to stop((if you have finished inserting projects)");
        while(input.hasNext()){
            projects.add(input.next());
            if(input.hasNext("end")){
                System.out.println("your project list is finalized");
            }


            project_submitted(projects);
        }}
    public void display(){
        //Displays the instructor's full name and address
        System.out.println(getFname());
        System.out.println(getLname());
        System.out.println(getID());
        System.out.println(getEmail());
        System.out.println(getPassword());



    }
}






